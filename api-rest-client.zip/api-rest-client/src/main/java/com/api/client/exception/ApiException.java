package com.api.client.exception;

import lombok.Getter;

/**
 * Exceção base para erros da API
 */
@Getter
public class ApiException extends RuntimeException {

    private final int statusCode;
    private final String errorMessage;

    public ApiException(int statusCode, String errorMessage) {
        super(String.format("API Error [%d]: %s", statusCode, errorMessage));
        this.statusCode = statusCode;
        this.errorMessage = errorMessage;
    }

    public ApiException(int statusCode, String errorMessage, Throwable cause) {
        super(String.format("API Error [%d]: %s", statusCode, errorMessage), cause);
        this.statusCode = statusCode;
        this.errorMessage = errorMessage;
    }
}
