package com.api.client.config;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;
import java.time.Duration;

/**
 * Configuração do WebClient para consumo da API REST
 */
@Slf4j
@Configuration
public class WebClientConfig {

    @Value("${api.base-url}")
    private String baseUrl;

    @Value("${api.timeout.connection:5000}")
    private int connectionTimeout;

    @Value("${api.timeout.read:10000}")
    private int readTimeout;

    @Value("${api.ssl.verify:true}")
    private boolean verifySsl;

    @Bean
    public WebClient webClient() {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(Duration.ofMillis(readTimeout));

        // Se SSL verification estiver desabilitado (apenas para desenvolvimento)
        if (!verifySsl) {
            log.warn("⚠️  ATENÇÃO: Validação SSL desabilitada! Use apenas em desenvolvimento.");
            try {
                SslContext sslContext = SslContextBuilder.forClient()
                        .trustManager(InsecureTrustManagerFactory.INSTANCE)
                        .build();
                httpClient = httpClient.secure(sslSpec -> sslSpec.sslContext(sslContext));
            } catch (SSLException e) {
                log.error("Erro ao configurar SSL context", e);
            }
        }

        return WebClient.builder()
                .baseUrl(baseUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .filter(logRequest())
                .filter(logResponse())
                .build();
    }

    /**
     * Filtro para log de requisições
     */
    private ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            log.debug("→ Request: {} {}", clientRequest.method(), clientRequest.url());
            clientRequest.headers().forEach((name, values) -> {
                if (!name.equalsIgnoreCase("Authorization")) {
                    values.forEach(value -> log.debug("  Header: {}: {}", name, value));
                } else {
                    log.debug("  Header: {}: [REDACTED]", name);
                }
            });
            return Mono.just(clientRequest);
        });
    }

    /**
     * Filtro para log de respostas
     */
    private ExchangeFilterFunction logResponse() {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            log.debug("← Response: {}", clientResponse.statusCode());
            return Mono.just(clientResponse);
        });
    }
}
