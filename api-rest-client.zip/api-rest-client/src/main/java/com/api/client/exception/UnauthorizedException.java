package com.api.client.exception;

/**
 * Exceção para erro 401 - Unauthorized
 * Token inválido, ausente ou expirado
 */
public class UnauthorizedException extends ApiException {

    public UnauthorizedException(String errorMessage) {
        super(401, errorMessage);
    }
}
