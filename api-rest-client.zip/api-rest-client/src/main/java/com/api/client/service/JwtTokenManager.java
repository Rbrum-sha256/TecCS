package com.api.client.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Optional;

/**
 * Gerenciador de token JWT
 * Armazena e gerencia o ciclo de vida do token de autenticação
 */
@Slf4j
@Component
public class JwtTokenManager {

    private String currentToken;
    private Instant expirationTime;

    /**
     * Armazena um novo token JWT
     *
     * @param token      Token JWT
     * @param expiresIn  Tempo de expiração em segundos
     */
    public void setToken(String token, int expiresIn) {
        this.currentToken = token;
        this.expirationTime = Instant.now().plusSeconds(expiresIn);
        log.debug("Token JWT armazenado. Expira em: {}", expirationTime);
    }

    /**
     * Retorna o token atual se válido
     *
     * @return Optional com o token ou empty se não houver token válido
     */
    public Optional<String> getToken() {
        if (currentToken == null) {
            log.debug("Nenhum token disponível");
            return Optional.empty();
        }

        if (isExpired()) {
            log.warn("Token expirado");
            clearToken();
            return Optional.empty();
        }

        return Optional.of(currentToken);
    }

    /**
     * Verifica se o token está expirado
     *
     * @return true se expirado ou não existe
     */
    public boolean isExpired() {
        if (expirationTime == null) {
            return true;
        }
        return Instant.now().isAfter(expirationTime);
    }

    /**
     * Verifica se há um token válido
     *
     * @return true se há token válido
     */
    public boolean hasValidToken() {
        return currentToken != null && !isExpired();
    }

    /**
     * Limpa o token armazenado
     */
    public void clearToken() {
        log.debug("Token JWT removido");
        this.currentToken = null;
        this.expirationTime = null;
    }

    /**
     * Retorna o tempo restante até a expiração em segundos
     *
     * @return segundos até expiração ou 0 se expirado/inexistente
     */
    public long getSecondsUntilExpiration() {
        if (expirationTime == null) {
            return 0;
        }
        long seconds = expirationTime.getEpochSecond() - Instant.now().getEpochSecond();
        return Math.max(0, seconds);
    }
}
