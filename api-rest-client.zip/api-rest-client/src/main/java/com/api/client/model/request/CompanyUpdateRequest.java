package com.api.client.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.*;

/**
 * Request para atualização de empresa
 * Nota: username NÃO pode ser editado
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompanyUpdateRequest {

    @Size(min = 4, max = 150, message = "Nome deve ter entre 4 e 150 caracteres")
    @JsonProperty("name")
    private String name;

    @Email(message = "Email deve ser válido")
    @Size(min = 10, max = 150, message = "Email deve ter entre 10 e 150 caracteres")
    @JsonProperty("email")
    private String email;

    @Size(min = 10, max = 12, message = "Telefone deve ter entre 10 e 12 caracteres")
    @JsonProperty("phone")
    private String phone;

    @Size(min = 3, max = 150, message = "Rua deve ter entre 3 e 150 caracteres")
    @JsonProperty("street")
    private String street;

    @Size(min = 1, max = 8, message = "Número deve ter entre 1 e 8 caracteres")
    @JsonProperty("number")
    private String number;

    @Size(min = 3, max = 150, message = "Cidade deve ter entre 3 e 150 caracteres")
    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @Size(min = 4, max = 150, message = "Ramo deve ter entre 4 e 150 caracteres")
    @JsonProperty("business")
    private String business;

    @Size(min = 3, max = 20, message = "Password deve ter entre 3 e 20 caracteres")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Password não pode conter caracteres especiais ou espaços")
    @JsonProperty("password")
    private String password;
}
