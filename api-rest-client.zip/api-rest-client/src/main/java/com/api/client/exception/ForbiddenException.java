package com.api.client.exception;

/**
 * Exceção para erro 403 - Forbidden
 * Token válido mas sem permissão para a operação
 */
public class ForbiddenException extends ApiException {

    public ForbiddenException(String errorMessage) {
        super(403, errorMessage);
    }
}
