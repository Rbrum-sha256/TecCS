package com.api.client;

import com.api.client.model.request.CompanyCreateRequest;
import com.api.client.model.request.CompanyUpdateRequest;
import com.api.client.model.response.CompanyResponse;
import com.api.client.service.AuthService;
import com.api.client.service.CompanyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Aplicação principal que demonstra o consumo da API REST
 */
@Slf4j
@SpringBootApplication
@RequiredArgsConstructor
public class Application implements CommandLineRunner {

    private final AuthService authService;
    private final CompanyService companyService;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) {
        log.info("=== Iniciando Cliente API REST ===");
        
        try {
            // Exemplo de uso da API
            demonstrarUsoAPI();
        } catch (Exception e) {
            log.error("Erro durante execução: {}", e.getMessage(), e);
        }
        
        log.info("=== Execução finalizada ===");
    }

    /**
     * Demonstra o uso completo da API
     */
    private void demonstrarUsoAPI() {
        log.info("\n--- Exemplo de Uso da API ---\n");
        
        // 1. Login
        log.info("1. Realizando login...");
        authService.login("madeirinho2", "senha");
        log.info("✓ Login realizado com sucesso!");
        
        // 2. Criar empresa (descomente para testar cadastro)
        /*
        log.info("\n2. Cadastrando nova empresa...");
        CompanyCreateRequest createRequest = CompanyCreateRequest.builder()
                .name("Empresa Teste")
                .business("Tecnologia")
                .username("empresateste")
                .password("senha123")
                .street("Rua Teste")
                .number("100")
                .city("Ponta Grossa")
                .state("PR")
                .phone("42999887766")
                .email("teste@empresa.com")
                .build();
        companyService.createCompany(createRequest);
        log.info("✓ Empresa cadastrada com sucesso!");
        */
        
        // 3. Buscar dados da empresa
        log.info("\n3. Buscando dados da empresa (ID: 1)...");
        CompanyResponse company = companyService.getCompany(1L);
        log.info("✓ Empresa encontrada: {}", company.getName());
        log.info("  - Business: {}", company.getBusiness());
        log.info("  - Email: {}", company.getEmail());
        log.info("  - Phone: {}", company.getPhone());
        
        // 4. Atualizar empresa (descomente para testar atualização)
        /*
        log.info("\n4. Atualizando dados da empresa...");
        CompanyUpdateRequest updateRequest = CompanyUpdateRequest.builder()
                .name("Empresa Atualizada")
                .email("novo@empresa.com")
                .phone("42988776655")
                .street("Nova Rua")
                .number("200")
                .city("Ponta Grossa")
                .state("PR")
                .business("Varejo")
                .password("novasenha")
                .build();
        companyService.updateCompany(1L, updateRequest);
        log.info("✓ Empresa atualizada com sucesso!");
        */
        
        // 5. Logout
        log.info("\n5. Realizando logout...");
        authService.logout();
        log.info("✓ Logout realizado com sucesso!");
    }
}
