package com.api.client.service;

import com.api.client.client.ApiClient;
import com.api.client.model.request.LoginRequest;
import com.api.client.model.response.LoginResponse;
import com.api.client.model.response.MessageResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Serviço de autenticação
 * Gerencia login e logout na API
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final ApiClient apiClient;
    private final JwtTokenManager tokenManager;

    /**
     * Realiza login na API
     *
     * @param username Nome de usuário
     * @param password Senha
     * @return Response com token e tempo de expiração
     */
    public LoginResponse login(String username, String password) {
        log.info("Realizando login para usuário: {}", username);

        LoginRequest request = LoginRequest.builder()
                .username(username)
                .password(password)
                .build();

        LoginResponse response = apiClient.post("/login", request, LoginResponse.class, false);

        // Armazena o token
        tokenManager.setToken(response.getToken(), response.getExpiresIn());

        log.info("Login realizado com sucesso. Token expira em {} segundos", response.getExpiresIn());
        return response;
    }

    /**
     * Realiza logout na API
     *
     * @return Response com mensagem de confirmação
     */
    public MessageResponse logout() {
        log.info("Realizando logout...");

        MessageResponse response = apiClient.post("/logout", MessageResponse.class, true);

        // Remove o token local
        tokenManager.clearToken();

        log.info("Logout realizado com sucesso");
        return response;
    }

    /**
     * Verifica se há autenticação válida
     *
     * @return true se autenticado
     */
    public boolean isAuthenticated() {
        return tokenManager.hasValidToken();
    }

    /**
     * Retorna o tempo restante até expiração do token em segundos
     *
     * @return segundos até expiração
     */
    public long getSecondsUntilExpiration() {
        return tokenManager.getSecondsUntilExpiration();
    }
}
