package com.api.client.exception;

import com.api.client.model.response.ErrorResponse;
import lombok.Getter;

import java.util.List;

/**
 * Exceção para erro 422 - Unprocessable Entity
 * Erro de validação de campos
 */
@Getter
public class ValidationException extends ApiException {

    private final List<ErrorResponse.ValidationDetail> validationDetails;

    public ValidationException(String errorMessage, List<ErrorResponse.ValidationDetail> validationDetails) {
        super(422, errorMessage);
        this.validationDetails = validationDetails;
    }

    @Override
    public String getMessage() {
        StringBuilder sb = new StringBuilder(super.getMessage());
        if (validationDetails != null && !validationDetails.isEmpty()) {
            sb.append("\nDetalhes de validação:");
            for (ErrorResponse.ValidationDetail detail : validationDetails) {
                sb.append(String.format("\n  - Campo '%s': %s", detail.getField(), detail.getError()));
            }
        }
        return sb.toString();
    }
}
