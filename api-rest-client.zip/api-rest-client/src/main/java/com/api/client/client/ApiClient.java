package com.api.client.client;

import com.api.client.exception.*;
import com.api.client.model.response.ErrorResponse;
import com.api.client.service.JwtTokenManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * Cliente HTTP base para consumo da API REST
 * Encapsula o WebClient e fornece métodos genéricos para requisições
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApiClient {

    private final WebClient webClient;
    private final JwtTokenManager tokenManager;

    /**
     * Executa requisição GET
     *
     * @param path          Caminho do endpoint
     * @param responseType  Classe do tipo de resposta
     * @param authenticated Se requer autenticação
     * @return Resposta deserializada
     */
    public <T> T get(String path, Class<T> responseType, boolean authenticated) {
        WebClient.RequestHeadersSpec<?> spec = webClient.get()
                .uri(path)
                .accept(MediaType.APPLICATION_JSON);

        if (authenticated) {
            spec = addAuthHeader(spec);
        }

        return spec.retrieve()
                .onStatus(HttpStatusCode::isError, this::handleErrorResponse)
                .bodyToMono(responseType)
                .block();
    }

    /**
     * Executa requisição POST
     *
     * @param path          Caminho do endpoint
     * @param body          Corpo da requisição
     * @param responseType  Classe do tipo de resposta
     * @param authenticated Se requer autenticação
     * @return Resposta deserializada
     */
    public <T, R> R post(String path, T body, Class<R> responseType, boolean authenticated) {
        WebClient.RequestHeadersSpec<?> spec = webClient.post()
                .uri(path)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .bodyValue(body);

        if (authenticated) {
            spec = addAuthHeader(spec);
        }

        return spec.retrieve()
                .onStatus(HttpStatusCode::isError, this::handleErrorResponse)
                .bodyToMono(responseType)
                .block();
    }

    /**
     * Executa requisição POST sem body
     *
     * @param path          Caminho do endpoint
     * @param responseType  Classe do tipo de resposta
     * @param authenticated Se requer autenticação
     * @return Resposta deserializada
     */
    public <R> R post(String path, Class<R> responseType, boolean authenticated) {
        WebClient.RequestHeadersSpec<?> spec = webClient.post()
                .uri(path)
                .accept(MediaType.APPLICATION_JSON);

        if (authenticated) {
            spec = addAuthHeader(spec);
        }

        return spec.retrieve()
                .onStatus(HttpStatusCode::isError, this::handleErrorResponse)
                .bodyToMono(responseType)
                .block();
    }

    /**
     * Executa requisição PATCH
     *
     * @param path          Caminho do endpoint
     * @param body          Corpo da requisição
     * @param responseType  Classe do tipo de resposta
     * @param authenticated Se requer autenticação
     * @return Resposta deserializada
     */
    public <T, R> R patch(String path, T body, Class<R> responseType, boolean authenticated) {
        WebClient.RequestHeadersSpec<?> spec = webClient.patch()
                .uri(path)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .bodyValue(body);

        if (authenticated) {
            spec = addAuthHeader(spec);
        }

        return spec.retrieve()
                .onStatus(HttpStatusCode::isError, this::handleErrorResponse)
                .bodyToMono(responseType)
                .block();
    }

    /**
     * Executa requisição DELETE
     *
     * @param path          Caminho do endpoint
     * @param responseType  Classe do tipo de resposta
     * @param authenticated Se requer autenticação
     * @return Resposta deserializada
     */
    public <R> R delete(String path, Class<R> responseType, boolean authenticated) {
        WebClient.RequestHeadersSpec<?> spec = webClient.delete()
                .uri(path)
                .accept(MediaType.APPLICATION_JSON);

        if (authenticated) {
            spec = addAuthHeader(spec);
        }

        return spec.retrieve()
                .onStatus(HttpStatusCode::isError, this::handleErrorResponse)
                .bodyToMono(responseType)
                .block();
    }

    /**
     * Adiciona header de autenticação JWT
     */
    private WebClient.RequestHeadersSpec<?> addAuthHeader(WebClient.RequestHeadersSpec<?> spec) {
        String token = tokenManager.getToken()
                .orElseThrow(() -> new UnauthorizedException("Token não disponível. Faça login primeiro."));
        return spec.header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
    }

    /**
     * Trata respostas de erro HTTP
     */
    private Mono<? extends Throwable> handleErrorResponse(org.springframework.web.reactive.function.client.ClientResponse response) {
        int statusCode = response.statusCode().value();

        return response.bodyToMono(ErrorResponse.class)
                .flatMap(errorResponse -> {
                    String message = errorResponse.getMessage() != null ? errorResponse.getMessage() : "Erro desconhecido";

                    return switch (statusCode) {
                        case 401 -> Mono.error(new UnauthorizedException(message));
                        case 403 -> Mono.error(new ForbiddenException(message));
                        case 404 -> Mono.error(new NotFoundException(message));
                        case 409 -> Mono.error(new ConflictException(message));
                        case 422 -> Mono.error(new ValidationException(message, errorResponse.getDetails()));
                        default -> Mono.error(new ApiException(statusCode, message));
                    };
                })
                .onErrorResume(throwable -> {
                    // Se não conseguir parsear o erro, retorna erro genérico
                    if (!(throwable instanceof ApiException)) {
                        return Mono.error(new ApiException(statusCode, "Erro ao processar resposta: " + throwable.getMessage()));
                    }
                    return Mono.error(throwable);
                });
    }
}
