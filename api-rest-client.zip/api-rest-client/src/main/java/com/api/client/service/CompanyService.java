package com.api.client.service;

import com.api.client.client.ApiClient;
import com.api.client.model.request.CompanyCreateRequest;
import com.api.client.model.request.CompanyUpdateRequest;
import com.api.client.model.response.CompanyResponse;
import com.api.client.model.response.MessageResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Serviço de operações com empresas
 * Implementa CRUD completo seguindo o protocolo da API
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CompanyService {

    private final ApiClient apiClient;

    /**
     * Cadastra uma nova empresa
     *
     * @param request Dados da empresa
     * @return Response com mensagem de confirmação
     */
    public MessageResponse createCompany(CompanyCreateRequest request) {
        log.info("Cadastrando nova empresa: {}", request.getName());

        MessageResponse response = apiClient.post("/companies", request, MessageResponse.class, false);

        log.info("Empresa cadastrada com sucesso: {}", request.getName());
        return response;
    }

    /**
     * Busca dados de uma empresa pelo ID
     * Apenas a própria empresa pode ver seus dados
     *
     * @param companyId ID da empresa
     * @return Dados da empresa
     */
    public CompanyResponse getCompany(Long companyId) {
        log.info("Buscando dados da empresa ID: {}", companyId);

        String path = String.format("/companies/%d", companyId);
        CompanyResponse response = apiClient.get(path, CompanyResponse.class, true);

        log.info("Dados da empresa recuperados: {}", response.getName());
        return response;
    }

    /**
     * Atualiza dados de uma empresa
     * Apenas a própria empresa pode se atualizar
     * Username NÃO pode ser editado
     *
     * @param companyId ID da empresa
     * @param request   Dados a serem atualizados
     * @return Response com mensagem de confirmação
     */
    public MessageResponse updateCompany(Long companyId, CompanyUpdateRequest request) {
        log.info("Atualizando empresa ID: {}", companyId);

        String path = String.format("/companies/%d", companyId);
        MessageResponse response = apiClient.patch(path, request, MessageResponse.class, true);

        log.info("Empresa atualizada com sucesso");
        return response;
    }

    /**
     * Deleta uma empresa
     * Apenas a própria empresa pode se deletar
     *
     * @param companyId ID da empresa
     * @return Response com mensagem de confirmação
     */
    public MessageResponse deleteCompany(Long companyId) {
        log.info("Deletando empresa ID: {}", companyId);

        String path = String.format("/companies/%d", companyId);
        MessageResponse response = apiClient.delete(path, MessageResponse.class, true);

        log.info("Empresa deletada com sucesso");
        return response;
    }
}
