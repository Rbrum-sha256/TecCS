package com.api.client.exception;

/**
 * Exceção para erro 404 - Not Found
 * Recurso não encontrado
 */
public class NotFoundException extends ApiException {

    public NotFoundException(String errorMessage) {
        super(404, errorMessage);
    }
}
