package com.api.client.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.*;

/**
 * Request para cadastro de empresa
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompanyCreateRequest {

    @NotBlank(message = "Nome é obrigatório")
    @Size(min = 4, max = 150, message = "Nome deve ter entre 4 e 150 caracteres")
    @JsonProperty("name")
    private String name;

    @NotBlank(message = "Ramo é obrigatório")
    @Size(min = 4, max = 150, message = "Ramo deve ter entre 4 e 150 caracteres")
    @JsonProperty("business")
    private String business;

    @NotBlank(message = "Username é obrigatório")
    @Size(min = 3, max = 20, message = "Username deve ter entre 3 e 20 caracteres")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Username não pode conter caracteres especiais ou espaços")
    @JsonProperty("username")
    private String username;

    @NotBlank(message = "Password é obrigatório")
    @Size(min = 3, max = 20, message = "Password deve ter entre 3 e 20 caracteres")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Password não pode conter caracteres especiais ou espaços")
    @JsonProperty("password")
    private String password;

    @NotBlank(message = "Rua é obrigatória")
    @Size(min = 3, max = 150, message = "Rua deve ter entre 3 e 150 caracteres")
    @JsonProperty("street")
    private String street;

    @NotBlank(message = "Número é obrigatório")
    @Size(min = 1, max = 8, message = "Número deve ter entre 1 e 8 caracteres")
    @JsonProperty("number")
    private String number;

    @NotBlank(message = "Cidade é obrigatória")
    @Size(min = 3, max = 150, message = "Cidade deve ter entre 3 e 150 caracteres")
    @JsonProperty("city")
    private String city;

    @NotBlank(message = "Estado é obrigatório")
    @JsonProperty("state")
    private String state;

    @NotBlank(message = "Telefone é obrigatório")
    @Size(min = 10, max = 12, message = "Telefone deve ter entre 10 e 12 caracteres")
    @JsonProperty("phone")
    private String phone;

    @NotBlank(message = "Email é obrigatório")
    @Email(message = "Email deve ser válido")
    @Size(min = 10, max = 150, message = "Email deve ter entre 10 e 150 caracteres")
    @JsonProperty("email")
    private String email;
}
