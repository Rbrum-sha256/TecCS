package com.api.client.exception;

/**
 * Exceção para erro 409 - Conflict
 * Conflito de dados (ex: username já existe)
 */
public class ConflictException extends ApiException {

    public ConflictException(String errorMessage) {
        super(409, errorMessage);
    }
}
