# API REST Client - Java Spring Boot

Cliente Java desenvolvido com **Spring Boot 3.x** para consumo de API REST com autenticação JWT (Bearer Token), seguindo fielmente o protocolo de troca de mensagens especificado.

## Características

- **WebClient** (reativo) para requisições HTTP
- **Autenticação JWT** com gerenciamento automático de tokens
- **Validação de campos** seguindo as especificações do protocolo
- **Tratamento robusto de erros** com exceções customizadas
- **Logs detalhados** para debug e monitoramento
- **Arquitetura limpa** com separação de responsabilidades
- **Suporte HTTPS** com opção de desabilitar validação SSL para desenvolvimento

## Tecnologias

- Java 17
- Spring Boot 3.2.0
- Spring WebFlux (WebClient)
- Lombok
- Jackson (JSON)
- Maven

## Estrutura do Projeto

```
com.api.client/
├── config/              # Configurações do Spring
│   └── WebClientConfig.java
├── model/               # DTOs
│   ├── request/         # Objetos de requisição
│   └── response/        # Objetos de resposta
├── service/             # Lógica de negócio
│   ├── AuthService.java
│   ├── CompanyService.java
│   └── JwtTokenManager.java
├── client/              # Cliente HTTP
│   └── ApiClient.java
├── exception/           # Exceções customizadas
└── Application.java     # Classe principal
```

## Configuração

Edite o arquivo `src/main/resources/application.yml`:

```yaml
api:
  base-url: https://localhost:8443  # URL base da API
  timeout:
    connection: 5000                 # Timeout de conexão (ms)
    read: 10000                      # Timeout de leitura (ms)
  ssl:
    verify: false                    # Validação SSL (false apenas para dev)
```

## Compilação

```bash
mvn clean package
```

## Execução

```bash
mvn spring-boot:run
```

Ou execute o JAR gerado:

```bash
java -jar target/api-rest-client-1.0.0.jar
```

## Uso Programático

### 1. Autenticação

```java
@Autowired
private AuthService authService;

// Login
LoginResponse response = authService.login("username", "password");
System.out.println("Token expira em: " + response.getExpiresIn() + " segundos");

// Verificar autenticação
boolean authenticated = authService.isAuthenticated();

// Logout
authService.logout();
```

### 2. Operações com Empresas

#### Cadastrar Empresa

```java
@Autowired
private CompanyService companyService;

CompanyCreateRequest request = CompanyCreateRequest.builder()
    .name("Empresa Teste")
    .business("Tecnologia")
    .username("empresateste")
    .password("senha123")
    .street("Rua Teste")
    .number("100")
    .city("Ponta Grossa")
    .state("PR")
    .phone("42999887766")
    .email("teste@empresa.com")
    .build();

MessageResponse response = companyService.createCompany(request);
```

#### Buscar Empresa

```java
CompanyResponse company = companyService.getCompany(1L);
System.out.println("Nome: " + company.getName());
System.out.println("Email: " + company.getEmail());
```

#### Atualizar Empresa

```java
CompanyUpdateRequest updateRequest = CompanyUpdateRequest.builder()
    .name("Novo Nome")
    .email("novo@email.com")
    .phone("42988776655")
    .build();

companyService.updateCompany(1L, updateRequest);
```

#### Deletar Empresa

```java
companyService.deleteCompany(1L);
```

## Tratamento de Erros

A aplicação lança exceções específicas para cada tipo de erro:

| Exceção                  | Status | Descrição                                      |
|--------------------------|--------|------------------------------------------------|
| `UnauthorizedException`  | 401    | Token inválido, ausente ou expirado            |
| `ForbiddenException`     | 403    | Token válido mas sem permissão                 |
| `NotFoundException`      | 404    | Recurso não encontrado                         |
| `ConflictException`      | 409    | Conflito (ex: username já existe)              |
| `ValidationException`    | 422    | Erro de validação de campos                    |
| `ApiException`           | Outros | Erro genérico da API                           |

### Exemplo de Tratamento

```java
try {
    companyService.getCompany(999L);
} catch (NotFoundException e) {
    System.err.println("Empresa não encontrada: " + e.getErrorMessage());
} catch (UnauthorizedException e) {
    System.err.println("Token inválido. Faça login novamente.");
} catch (ApiException e) {
    System.err.println("Erro na API [" + e.getStatusCode() + "]: " + e.getErrorMessage());
}
```

## Protocolo da API

### Endpoints Implementados

| Método | Endpoint                | Autenticação | Descrição              |
|--------|-------------------------|--------------|------------------------|
| POST   | /login                  | Não          | Autenticação           |
| POST   | /logout                 | Sim          | Logout                 |
| POST   | /companies              | Não          | Cadastrar empresa      |
| GET    | /companies/{id}         | Sim          | Buscar empresa         |
| PATCH  | /companies/{id}         | Sim          | Atualizar empresa      |
| DELETE | /companies/{id}         | Sim          | Deletar empresa        |

### Validações de Campos (Empresa)

- **name**: 4-150 caracteres
- **business**: 4-150 caracteres
- **username**: 3-20 caracteres, único, sem caracteres especiais
- **password**: 3-20 caracteres, sem caracteres especiais
- **street**: 3-150 caracteres
- **number**: 1-8 caracteres, número inteiro positivo ou vazio
- **city**: 3-150 caracteres
- **state**: Estado válido
- **phone**: 10-12 caracteres (sem +55)
- **email**: 10-150 caracteres, formato válido

## Logs

A aplicação gera logs detalhados:

```
2024-11-03 10:30:15 - Realizando login para usuário: madeirinho2
2024-11-03 10:30:15 - → Request: POST https://localhost:8443/login
2024-11-03 10:30:15 - ← Response: 200 OK
2024-11-03 10:30:15 - Login realizado com sucesso. Token expira em 3600 segundos
```

## Segurança

- Token JWT armazenado **apenas em memória** (não persistido)
- HTTPS obrigatório para comunicação
- Validação de certificados SSL (configurável)
- Logs não expõem tokens ou senhas

## Desenvolvimento

### Desabilitar Validação SSL (Apenas Dev)

No `application.yml`:

```yaml
api:
  ssl:
    verify: false
```

⚠️ **ATENÇÃO**: Nunca desabilite validação SSL em produção!

## Testes

Execute os testes com:

```bash
mvn test
```

## Licença

Este projeto é fornecido como exemplo educacional.
