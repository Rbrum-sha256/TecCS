# Guia de Início Rápido

Este guia apresenta os passos essenciais para começar a usar o cliente API REST em poucos minutos.

## Pré-requisitos

Antes de iniciar, certifique-se de ter instalado:

- **Java 17** ou superior
- **Maven 3.6+**
- Acesso à API REST (URL base e credenciais)

## Passo 1: Configurar a Aplicação

Abra o arquivo `src/main/resources/application.yml` e configure a URL base da sua API:

```yaml
api:
  base-url: https://localhost:8443  # Altere para a URL da sua API
  ssl:
    verify: false  # Use 'true' em produção
```

## Passo 2: Compilar o Projeto

No diretório raiz do projeto, execute:

```bash
mvn clean package
```

Este comando irá baixar todas as dependências e compilar o projeto.

## Passo 3: Executar a Aplicação

Execute a aplicação com:

```bash
mvn spring-boot:run
```

Ou execute o JAR gerado:

```bash
java -jar target/api-rest-client-1.0.0.jar
```

## Passo 4: Personalizar o Exemplo

A classe `Application.java` contém um exemplo de uso. Para personalizá-lo:

1. Abra `src/main/java/com/api/client/Application.java`
2. Localize o método `demonstrarUsoAPI()`
3. Altere as credenciais de login:

```java
authService.login("seu_username", "sua_senha");
```

4. Altere o ID da empresa na busca:

```java
CompanyResponse company = companyService.getCompany(1L); // Altere o ID
```

5. Descomente as seções de criar/atualizar empresa conforme necessário

## Exemplo Completo de Uso

```java
// 1. Fazer login
authService.login("madeirinho2", "senha");

// 2. Buscar dados da empresa
CompanyResponse company = companyService.getCompany(1L);
System.out.println("Empresa: " + company.getName());

// 3. Atualizar dados
CompanyUpdateRequest update = CompanyUpdateRequest.builder()
    .email("novo@email.com")
    .phone("42988776655")
    .build();
companyService.updateCompany(1L, update);

// 4. Fazer logout
authService.logout();
```

## Tratamento de Erros

Sempre envolva as chamadas em blocos try-catch:

```java
try {
    authService.login("username", "password");
} catch (UnauthorizedException e) {
    System.err.println("Credenciais inválidas: " + e.getErrorMessage());
} catch (ApiException e) {
    System.err.println("Erro na API: " + e.getErrorMessage());
}
```

## Próximos Passos

- Leia o [README.md](README.md) para documentação completa
- Explore os serviços disponíveis em `src/main/java/com/api/client/service/`
- Adicione novos endpoints conforme necessário
- Implemente testes unitários em `src/test/java/`

## Problemas Comuns

### Erro de conexão SSL

Se encontrar erros de certificado SSL, configure temporariamente:

```yaml
api:
  ssl:
    verify: false
```

**Atenção**: Use apenas em desenvolvimento!

### Token expirado

O token JWT expira após o tempo definido pela API. Faça login novamente quando necessário:

```java
if (!authService.isAuthenticated()) {
    authService.login("username", "password");
}
```

### Erro 403 - Forbidden

Você está tentando acessar um recurso que não pertence ao usuário autenticado. Verifique:
- O ID da empresa corresponde ao usuário logado
- O role do usuário tem permissão para a operação

## Suporte

Para mais informações, consulte:
- [README.md](README.md) - Documentação completa
- Arquivo Excel com protocolo de troca de mensagens
- Logs da aplicação em modo DEBUG
